package battleship;

import java.util.Arrays;
import java.util.Scanner;

public class Console {

    // This flag tells if user`s input was 'exit' or not.
    // As soon as its value becomes true, the program shall end.
    static boolean wasInputExit = false;

    static Scanner scanner = new Scanner(System.in);


    public static boolean isInputInt(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * gets correct int input from user
     *
     * @param minValue minimum allowed value
     * @param maxValue maximum allowed value
     * @return Integer.MIN_VALUE, if user entered 'exit', user`s input otherwise.
     */
    public static int getNumberInFixedRange(int minValue, int maxValue) {
        String input = scanner.next();
        while ((!isInputInt(input) || Integer.parseInt((input)) < minValue
                || Integer.parseInt(input) > maxValue) && input != "exit") {
            System.out.print(String.format("Please enter an integer in range [%d;%d] " +
                    "or type 'exit' if you want to finish the game.\n", minValue, maxValue));
            input = scanner.next();
        }
        if (input == "exit") {
            return Integer.MIN_VALUE;
        }
        return Integer.parseInt(input);
    }

    static Field initializeField(String mode) {
        System.out.print("Now choose the parameters of the battlefield " +
                "(the ocean size)\nEnter amount of rows(integer in range [5;30]):");
        int rows = getNumberInFixedRange(5, 30);
        // It means that user entered 'exit'.
        if (rows == Integer.MIN_VALUE) {
            wasInputExit = true;
            return null;
        }
        System.out.println("Now enter amount of columns ([5;30]):");
        int columns = getNumberInFixedRange(5, 30);
        if (columns == Integer.MIN_VALUE) {
            wasInputExit = true;
            return null;
        }
        int torpedoesAmount = 0;
        if (mode == "T") {
            System.out.print("Now enter amount of torpedoes" +
                    " you would like to start with(int in range [0;500]): ");
            torpedoesAmount = getNumberInFixedRange(0, 500);
        }
        if (torpedoesAmount == Integer.MIN_VALUE) {
            wasInputExit = true;
            return null;
        }
        return new Field(rows, columns, torpedoesAmount, mode);
    }

    static void scrollConsole() {
        for (int i = 0; i < 40; ++i) {
            System.out.println("\n");
        }
    }

    static String GetCorrectInput(String[] correctOptions, Scanner scanner) {
        String input = "";
        while (!Arrays.asList(correctOptions).contains(input)) {
            input = scanner.next();
        }
        return input;
    }

    static String selectMode() {
        System.out.println("Choose mode to play:\n" +
                "If you want to enable Torpedo Mode, type 'T'\n" +
                "If you want to enable Recover Mode, type 'R'\n" +
                "If you want both of the Mods enabled, type 'TR'\n'" +
                "To play by normal rules, type anything else");
        return scanner.next();
    }

    static void displayField(Field field) {
        System.out.print("\n  ");
        for (int j = 0; j < field.getColumnsAmount(); ++j) {
            System.out.print(String.format("%d  "));
        }
        for (int i = 0; i < field.getRowsAmount(); ++i) {
            System.out.println();
            System.out.print(String.format("%d  ", i + 1));
            for (int j = 0; j < field.getColumnsAmount(); ++j) {
                System.out.print(field.getCellStatus(i,j));
                System.out.print("  ");
            }
        }
    }

}
