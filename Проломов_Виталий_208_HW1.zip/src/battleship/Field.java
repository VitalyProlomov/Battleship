package battleship;

import javax.lang.model.type.ArrayType;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Field {

    static private int shotsFired = 0;
    static private int torpedoesLeft = 0;

    private Cell[][] allCellsMatrix;
    // Possible values: "T" - torpedo mode, "R" - recovery mode,
    // "TR" - torpedo recovery, any other value - normal mode.
    private final String mode;
    private ArrayList<Ship> allShips = new ArrayList<Ship>();


    public Field(int rows, int columns) {
        this(rows, columns, 0);
    }

    public Field(int rows, int columns, int torpedoesAmount) {
        this(rows, columns, torpedoesAmount, "normal");
    }

    public Field(int rows, int columns, int torpedoesAmount, String mode) {
        allCellsMatrix = new Cell[rows][columns];
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                allCellsMatrix[i][j] = new Cell(i, j);
            }
        }
        torpedoesLeft = torpedoesAmount;
        shotsFired = 0;
        this.mode = mode;
    }

    public int getRowsAmount() {
        return allCellsMatrix.length;
    }

    public int getColumnsAmount() {
        return allCellsMatrix[0].length;
    }




    private void Clear() {
        for (int i = 0; i < allCellsMatrix.length; ++i) {
            for (int j = 0; j < allCellsMatrix[0].length; ++j) {
                allCellsMatrix[i][j] = new Cell(i, j);
            }
        }
    }

    public Cell.CellStatus getCellStatus(int row_index, int column_index) {
        return allCellsMatrix[row_index][column_index].getStatus();
    }

    public String ShootRegular(int row_coordinate, int column_index) {
        Cell currentCell = allCellsMatrix[row_coordinate][column_index];
        Cell.CellStatus currentStatus = currentCell.getStatus();
        if (currentStatus == Cell.CellStatus.NOT_SHOT) {
            shotsFired++;
            if (currentCell.getAssignedShipDeck() == null) {
                currentCell.setStatus(Cell.CellStatus.MISSED_SHOT);
                return "You missed";
            } else {
                ShipDeck shotDeck = currentCell.getAssignedShipDeck();
                shotDeck.getAssignedShip().handleShot(shotDeck, false);
                if (shotDeck.getAssignedShip().getIsSunk()) {
                    shotDeck.getAssignedShip().updateSunkStatus();
                    return String.format("Wonderful, you`ve just eliminated enemy`s" +
                            "%s ", shotDeck.getAssignedShip().toString());
                }
                shotDeck.getAssignedCell().setStatus(Cell.CellStatus.MISSED_SHOT);
                return "Great, you damaged one of the ships";
            }
        } else {
            return "You`ve already shot here, try another cell (shot is not counted).";
        }

    }

    public String ShootTorpedo(int row_coordinate, int column_index) {
        Cell currentCell = allCellsMatrix[row_coordinate][column_index];
        if (currentCell.getStatus() == Cell.CellStatus.NOT_SHOT) {
            shotsFired++;
            torpedoesLeft--;
            if (currentCell.getAssignedShipDeck() == null) {
                currentCell.setStatus(Cell.CellStatus.MISSED_SHOT);
                return "You missed";
            }

            Ship currentShip = currentCell.getAssignedShipDeck().getAssignedShip();
            currentShip.sink();
            currentShip.updateSunkStatus();
            return String.format("Great job, you've eliminated enemy`s %s",
                    currentShip.toString());
        }
        else {
            return "You`ve already shot there, shot is not counted";
        }
    }


    public void inputShips() {
        System.out.println("Now enter how much ships of each kind you would" +
                "like to battle against\n" +
                "You should enter a row of 5 positive integers seperated by 1 space each,\n" +
                "where n-th number in a row represents amount of n-deck ships generated." +
                "Example: \n" +
                "If you want 2 single-deck ships and 1 4-deck ship, enter \n" +
                "2 0 0 1 0\n" +
                "!!Constraints!! - each number must be in range [0;50]");
        boolean wasInputWrong = false;
        int parameters[];
        do {
            parameters = inputCorrectShipAmounts();
            if (Console.wasInputExit) {
                return;
            }
            int amountOfShips = 0;
            for (int j = 0; j < parameters.length; ++j) {
                amountOfShips+= parameters[j];
            }
            wasInputWrong = amountOfShips < allCellsMatrix.length/2 -1;

            if (wasInputWrong) {
                System.out.println("\n\nComputer was unable to insert to generate game with such parameters.\n" +
                        "That could`ve happened for 2 reasons:\n" +
                        "1) Such configuration is simply impossible\n" +
                        "2) There is a very limited amount of ways\n" +
                        "it could place the ships on the field.\n" +
                        "So, the computer could not find any possible ones.");
                System.out.println("Try another set of numbers:");
            }
        } while (wasInputWrong || !tryInsertShipsRandomly(parameters));

    }

    private int[] inputCorrectShipAmounts() {
        Scanner scanner1 = new Scanner(System.in);
        String input =  scanner1.nextLine();
        boolean wasInputCorrect = true;
        while (true) {
            int[] shipsAmounts = new int[1];
            if (input == "exit") {
                Console.wasInputExit = true;
                return null;
            }
            if (input.split(" ").length == 5) {
                 shipsAmounts = new int[input.split(" ").length];
                for (int i = 0; i < shipsAmounts.length; ++i) {
                    String inputAmount = input.split(" ")[i];
                    try {
                        int number = Integer.parseInt(inputAmount);
                        shipsAmounts[i] = number;
                    } catch (Exception ex) {
                        wasInputCorrect = false;
                        break;
                    }
                }
            }
                if (wasInputCorrect) {
                    return shipsAmounts;
                }
                else {
                    System.out.println("Incorrect input, please enter" +
                            "a row of 5 positive integers\n seperated by 1" +
                            "space each, where n-th number in a row represents \n" +
                            "amount of n-deck ships generated");
                    input = Console.scanner.nextLine();
                }

        }

    }


    /**
     * Adding all entered ships in Field.allShips List.
     *
     * @param shipsAmounts user`s input - amounts of each type of ship.
     */
    private int findShipSpace(int[] shipsAmounts) {
        int neededSpaceSum = 0;
        for (int decksAmount = 1; decksAmount <= 5; ++decksAmount) {
            for (int i = 0; i < shipsAmounts[decksAmount - 1]; ++i) {
                switch (decksAmount) {
                    case 1:
                        allShips.add((new Submarine()));
                        break;
                    case 2:
                        allShips.add((new Destroyer()));
                        break;
                    case 3:
                        allShips.add((new Cruiser()));
                        break;
                    case 4:
                        allShips.add((new BattleShip()));
                        break;
                    case 5:
                        allShips.add((new Carrier()));
                        break;
                }
                // On every iteration we add amount of cells that the ship is going
                // to occupy on the field if it does not touch the borders of the
                // field and does not neighbour with any other ships.
                neededSpaceSum += (allShips.get(i).getLength() * 3) + 6;
            }
        }
        return neededSpaceSum;
    }

    Random rnd = new Random();
    final int INSERT_SHIP_ATTEMPTS = 20;
    final int FIELD_RESET_ATTEMPTS = 200;

    /**
     * Here I am going to try to insert ships to the field randomly
     * by choosing a cell for its head and then inserting the rest
     * of the cells either upwards or to the left of the head.
     * I will also only choose the position for the head X cells
     * down from the top border and X cells right left borders of the field,
     * where X = length of ship. That way indexes never get out of bounds.
     *
     * @param parameters amounts of each ship type
     * @return flag, showing was insertion successful or not.
     */
    private boolean tryInsertShipsRandomly(int[] parameters) {
        boolean wasWholeInsertionSuccessful = false;
        int fieldResetsLeft = FIELD_RESET_ATTEMPTS;
        while (!wasWholeInsertionSuccessful && fieldResetsLeft > 0) {
            for (int currentShipIndex = 0; currentShipIndex < allShips.size(); ++currentShipIndex) {
                boolean wasCurrentShipInserted = false;
                int shipIsertionAttemptsLeft = INSERT_SHIP_ATTEMPTS;
                while (!wasCurrentShipInserted && shipIsertionAttemptsLeft > 0) {
                    int lowerBorder = allShips.get(currentShipIndex).getLength() - 1;
                    // Index of the last row
                    int upperBorder = allCellsMatrix.length - 1;
                    int rowCoord = (int) (rnd.nextDouble() * (upperBorder - lowerBorder) + lowerBorder);
                    upperBorder = allCellsMatrix[0].length - 1;
                    int columnCoord = (int) (rnd.nextDouble() * (upperBorder - lowerBorder) + lowerBorder);
                    boolean isDirectionUp = ((int) (rnd.nextDouble() * 10) % 2 == 0);

                    boolean canBeInserted = true;
                    // Checking if ship can be inserted at current coordinates.
                    for (int i = 0; i < allShips.get(currentShipIndex).getLength(); ++i) {
                        if (isDirectionUp) {
                            Cell currentInsertionCell = allCellsMatrix[rowCoord - i][columnCoord];
                            if (areThereAnyNeighbours(currentInsertionCell)) {
                                canBeInserted = false;
                                shipIsertionAttemptsLeft--;
                                break;
                            }
                        } else {
                            Cell currentInsertionCell = allCellsMatrix[rowCoord][columnCoord + i];
                            if (areThereAnyNeighbours(currentInsertionCell)) {
                                canBeInserted = false;
                                shipIsertionAttemptsLeft--;
                                break;
                            }
                        }
                    }
                    Ship currentShip = allShips.get(currentShipIndex);
                    // Actually inserting the ship if possible.
                    if (canBeInserted) {
                        for (int i = 0; i < currentShip.getLength(); ++i) {
                            if (isDirectionUp) {
                                Cell currentInsertionCell = allCellsMatrix[rowCoord - i][columnCoord];
                                currentInsertionCell.setAssignedShipDeck(currentShip.allDecks[i]);
                            } else {
                                Cell currentInsertionCell = allCellsMatrix[rowCoord][columnCoord + i];
                                currentInsertionCell.setAssignedShipDeck(currentShip.allDecks[i]);
                            }
                        }
                    }
                    wasCurrentShipInserted = canBeInserted;
                }

                if (shipIsertionAttemptsLeft <= 0) {
                    fieldResetsLeft--;
                    currentShipIndex = 0;
                }

            }
            fieldResetsLeft--;
        }
        if (fieldResetsLeft <= 0) {
            return false;
        }
        return true;
    }


    boolean areThereAnyNeighbours(Cell cell) {
        int row = cell.getRow_coordinate();
        int column = cell.getColumn_coordinate();
        for (int i = row - 1; i <= row + 1; ++i) {
            for (int j = column - 1; j <= column + 1; ++j) {
                if (i < allCellsMatrix.length && i >= 0 &&
                        j < allCellsMatrix[0].length && j >= 0) {
                    if (allCellsMatrix[i][j].getAssignedShipDeck() != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


}
