package battleship;

public class FieldInitializer {

}
