package battleship;

public class Main {
    static boolean wasInputExit = Console.wasInputExit;
    public static void main(String[] args) {
        System.out.println("Hello, User!");
        while (!wasInputExit) {
            String mode = Console.selectMode();
            if (wasInputExit) {
                break;
            }

            Field field = Console.initializeField(mode);
            if (wasInputExit) {
                break;
            }

            field.inputShips();
            if (wasInputExit) {
                break;
            }
            Console.displayField(field);

        }
        System.out.println("Bye!");
    }
}
